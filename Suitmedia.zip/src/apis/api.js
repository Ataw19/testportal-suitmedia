export const fetchIdeas = async ({
  page = 1,
  size = 10,
  sort = "-published_at",
}) => {
  try {
    const params = new URLSearchParams();
    params.append("page[number]", page);
    params.append("page[size]", size);
    params.append("sort", sort);
    params.append("append[]", "small_image");
    params.append("append[]", "medium_image");

    const response = await fetch(`/api/ideas?${params.toString()}`);

    if (!response.ok) {
      throw new Error("Network response was not ok");
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Failed to fetch ideas:", error);
    return { data: [], meta: { total: 0 } };
  }
};
