import Banner from "../components/Banner";
import IdeaCard from "../components/IdeaCard";
import { fetchIdeas } from "../apis/api";
import { useEffect, useState } from "react";

const Ideas = () => {
  const [ideas, setIdeas] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadIdeas = async () => {
      const response = await fetchIdeas({ page: 1, size: 10 });
      console.log("Fetched ideas:", response);
      setIdeas(response.data);
      setLoading(false);
    };

    loadIdeas();
  }, []);

  return (
    <>
      <Banner />
      {loading ? (
        <p>Loading ideas...</p>
      ) : (
        <div className="grid md:grid-cols-3 sm:grid-cols-2 grid-cols-1 gap-6">
          {ideas.map((idea) => (
            <IdeaCard key={idea.id} idea={idea} />
          ))}
        </div>
      )}
    </>
  );
};

export default Ideas;
