import React from "react";

const Careers = () => {
  return <div>Careers</div>;
};

export default Careers;
