import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import https from "node:https";

// https://vite.dev/config/
export default defineConfig({
  server: {
    proxy: {
      "/api": {
        target: "https://suitmedia-backend.suitdev.com",
        changeOrigin: true,
        secure: false,
        agent: new https.Agent({
          rejectUnauthorized: false,
        }),
      },
    },
  },
  plugins: [react(), tailwindcss()],
});
